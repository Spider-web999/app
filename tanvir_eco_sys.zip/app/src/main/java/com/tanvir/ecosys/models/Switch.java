package com.tanvir.ecosys.models;

import java.util.UUID;

public class Switch {
    private String id;
    private String name;
    private boolean isOn;
    private ConnectionType connectionType;
    private String macAddress;
    private String ipAddress;
    private boolean isConnected;
    private long lastSyncTime;
    private Schedule schedule;
    private int position;

    public enum ConnectionType {
        WIFI,
        BLUETOOTH,
        NONE
    }

    // Constructor for new switch
    public Switch(String name, String macAddress) {
        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.macAddress = macAddress;
        this.isOn = false;
        this.connectionType = ConnectionType.NONE;
        this.isConnected = false;
        this.lastSyncTime = System.currentTimeMillis();
        this.position = 0;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isOn() {
        return isOn;
    }

    public void setOn(boolean on) {
        isOn = on;
        lastSyncTime = System.currentTimeMillis();
    }

    public ConnectionType getConnectionType() {
        return connectionType;
    }

    public void setConnectionType(ConnectionType connectionType) {
        this.connectionType = connectionType;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public boolean isConnected() {
        return isConnected;
    }

    public void setConnected(boolean connected) {
        isConnected = connected;
        if (connected) {
            lastSyncTime = System.currentTimeMillis();
        }
    }

    public long getLastSyncTime() {
        return lastSyncTime;
    }

    public Schedule getSchedule() {
        return schedule;
    }

    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    // Helper methods
    public boolean needsSync() {
        return System.currentTimeMillis() - lastSyncTime > 300000; // 5 minutes
    }

    public String getStatusText() {
        if (isConnected) {
            return "Connected via " + connectionType.toString();
        } else {
            return "Disconnected";
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Switch aSwitch = (Switch) o;
        return id.equals(aSwitch.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}
