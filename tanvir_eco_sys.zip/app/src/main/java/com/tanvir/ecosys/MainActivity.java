package com.tanvir.ecosys;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.tanvir.ecosys.adapters.SwitchAdapter;
import com.tanvir.ecosys.interfaces.ConnectionCallback;
import com.tanvir.ecosys.managers.SwitchManager;
import com.tanvir.ecosys.models.Switch;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements 
    SwitchAdapter.SwitchItemListener, ConnectionCallback {

    private static final int PERMISSION_REQUEST_CODE = 123;
    private static final int REQUEST_ENABLE_BT = 1;

    private SwitchManager switchManager;
    private SwitchAdapter switchAdapter;
    private RecyclerView recyclerView;
    private FloatingActionButton fabAddDevice;
    private View connectionStatusBar;
    private TabLayout tabLayout;
    private ViewPager2 viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        initializeViews();
        
        // Setup toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Initialize switch manager
        switchManager = SwitchManager.getInstance(this);

        // Setup RecyclerView
        setupRecyclerView();

        // Setup FAB
        setupFab();

        // Check and request permissions
        checkAndRequestPermissions();

        // Setup ViewPager and TabLayout
        setupViewPagerAndTabs();
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerView);
        fabAddDevice = findViewById(R.id.fabAddDevice);
        connectionStatusBar = findViewById(R.id.connectionStatusBar);
        tabLayout = findViewById(R.id.tabLayout);
        viewPager = findViewById(R.id.viewPager);
    }

    private void setupRecyclerView() {
        switchAdapter = new SwitchAdapter(this, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(switchAdapter);
        switchAdapter.attachToRecyclerView(recyclerView);
    }

    private void setupFab() {
        fabAddDevice.setOnClickListener(v -> {
            // Start device scanning
            startDeviceScanning();
        });
    }

    private void setupViewPagerAndTabs() {
        // TODO: Implement ViewPager adapter and fragments
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void checkAndRequestPermissions() {
        String[] permissions = {
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        };

        ArrayList<String> permissionsNeeded = new ArrayList<>();

        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission)
                != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(permission);
            }
        }

        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                permissionsNeeded.toArray(new String[0]),
                PERMISSION_REQUEST_CODE);
        }
    }

    private void startDeviceScanning() {
        // Show scanning progress in status bar
        connectionStatusBar.setVisibility(View.VISIBLE);
        
        // Start scanning for devices
        switchManager.scanForDevices(this);
    }

    // SwitchAdapter.SwitchItemListener implementations
    @Override
    public void onSwitchToggled(Switch switchItem, boolean isOn) {
        switchManager.toggleSwitch(switchItem, isOn, this);
    }

    @Override
    public void onSwitchClicked(Switch switchItem) {
        // Show switch details/control dialog
        showSwitchDetailsDialog(switchItem);
    }

    @Override
    public void onSwitchLongPressed(Switch switchItem) {
        // Show edit dialog
        showEditSwitchDialog(switchItem);
    }

    @Override
    public void onSwitchPositionChanged(Switch switchItem, int newPosition) {
        switchManager.updateSwitchPosition(switchItem, newPosition);
    }

    // ConnectionCallback implementations
    @Override
    public void onConnectionStateChanged(Switch device, boolean isConnected) {
        runOnUiThread(() -> {
            switchAdapter.updateSwitch(device);
            showConnectionStatus(device, isConnected);
        });
    }

    @Override
    public void onCommandSent(Switch device, boolean success) {
        runOnUiThread(() -> {
            if (!success) {
                showError(device, "Failed to send command");
            }
            switchAdapter.updateSwitch(device);
        });
    }

    @Override
    public void onDeviceDiscovered(Switch device) {
        runOnUiThread(() -> {
            switchAdapter.addSwitch(device);
        });
    }

    @Override
    public void onError(Switch device, String error) {
        runOnUiThread(() -> {
            showError(device, error);
        });
    }

    @Override
    public void onDeviceSynced(Switch device) {
        runOnUiThread(() -> {
            switchAdapter.updateSwitch(device);
        });
    }

    private void showSwitchDetailsDialog(Switch switchItem) {
        new MaterialAlertDialogBuilder(this)
            .setTitle(switchItem.getName())
            .setMessage("Connection: " + switchItem.getConnectionType() + "\n" +
                       "Status: " + (switchItem.isOn() ? "ON" : "OFF"))
            .setPositiveButton(getString(R.string.button_ok), null)
            .setNeutralButton(getString(R.string.title_schedule), (dialog, which) -> {
                Intent intent = new Intent(this, ScheduleActivity.class);
                intent.putExtra("switch_id", switchItem.getId());
                startActivity(intent);
            })
            .show();
    }

    private void showEditSwitchDialog(Switch switchItem) {
        // TODO: Implement edit dialog
    }

    private void showConnectionStatus(Switch device, boolean isConnected) {
        String message = device.getName() + " is " + 
            (isConnected ? "connected" : "disconnected");
        Snackbar.make(recyclerView, message, Snackbar.LENGTH_SHORT).show();
    }

    private void showError(Switch device, String error) {
        String message = device.getName() + ": " + error;
        Snackbar.make(recyclerView, message, Snackbar.LENGTH_LONG)
            .setAction(getString(R.string.button_retry), v -> {
                switchManager.connectToDevice(device, this);
            })
            .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        switchManager.cleanup();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, 
                                         @NonNull String[] permissions,
                                         @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (!allGranted) {
                Toast.makeText(this, getString(R.string.error_location_permission),
                    Toast.LENGTH_LONG).show();
            }
        }
    }
}
