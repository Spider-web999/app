package com.example.smartswitchapp.models;

import java.util.Calendar;

public class Schedule {
    private Calendar startTime;
    private Calendar endTime;
    private boolean isRecurring;
    private int frequency; // e.g., daily, weekly

    public Schedule(Calendar startTime, Calendar endTime, boolean isRecurring, int frequency) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.isRecurring = isRecurring;
        this.frequency = frequency;
    }

    public Calendar getStartTime() {
        return startTime;
    }

    public void setStartTime(Calendar startTime) {
        this.startTime = startTime;
    }

    public Calendar getEndTime() {
        return endTime;
    }

    public void setEndTime(Calendar endTime) {
        this.endTime = endTime;
    }

    public boolean isRecurring() {
        return isRecurring;
    }

    public void setRecurring(boolean recurring) {
        isRecurring = recurring;
    }

    public int getFrequency() {
        return frequency;
    }

    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }

    public boolean isActive() {
        Calendar now = Calendar.getInstance();
        return now.after(startTime) && now.before(endTime);
    }
}
