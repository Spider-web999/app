package com.example.smartswitchapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartswitchapp.R;
import com.example.smartswitchapp.models.Switch;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SwitchAdapter extends RecyclerView.Adapter<SwitchAdapter.SwitchViewHolder> 
    implements ItemTouchHelperAdapter {

    private final Context context;
    private final List<Switch> switches;
    private final SwitchItemListener listener;
    private final ItemTouchHelper touchHelper;

    public SwitchAdapter(Context context, SwitchItemListener listener) {
        this.context = context;
        this.switches = new ArrayList<>();
        this.listener = listener;
        ItemTouchHelper.Callback callback = new SwitchItemTouchHelperCallback(this);
        this.touchHelper = new ItemTouchHelper(callback);
    }

    @NonNull
    @Override
    public SwitchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_switch, parent, false);
        return new SwitchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SwitchViewHolder holder, int position) {
        Switch switchItem = switches.get(position);
        
        // Set switch name
        holder.switchName.setText(switchItem.getName());
        
        // Set switch status
        holder.switchStatus.setText(switchItem.getStatusText());
        
        // Set switch state
        holder.switchToggle.setChecked(switchItem.isOn());
        holder.switchToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (listener != null) {
                listener.onSwitchToggled(switchItem, isChecked);
            }
        });
        
        // Set connection type icon
        switch (switchItem.getConnectionType()) {
            case WIFI:
                holder.connectionType.setImageResource(R.drawable.ic_wifi);
                break;
            case BLUETOOTH:
                holder.connectionType.setImageResource(R.drawable.ic_bluetooth);
                break;
            default:
                holder.connectionType.setImageResource(R.drawable.ic_disconnected);
        }
        
        // Set switch icon color based on state
        int iconTint = context.getColor(switchItem.isOn() ? 
            R.color.switch_on : R.color.switch_off);
        holder.switchIcon.setColorFilter(iconTint);
        
        // Show schedule info if available
        if (switchItem.getSchedule() != null) {
            holder.scheduleInfo.setVisibility(View.VISIBLE);
            holder.scheduleInfo.setText("Next: " + 
                (switchItem.getSchedule().isActive() ? "ON" : "OFF"));
        } else {
            holder.scheduleInfo.setVisibility(View.GONE);
        }
        
        // Setup drag handle
        holder.dragHandle.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                touchHelper.startDrag(holder);
            }
            return false;
        });
        
        // Set click listener for the whole item
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onSwitchClicked(switchItem);
            }
        });
        
        // Set long click listener for editing
        holder.itemView.setOnLongClickListener(v -> {
            if (listener != null) {
                listener.onSwitchLongPressed(switchItem);
                return true;
            }
            return false;
        });
    }

    @Override
    public int getItemCount() {
        return switches.size();
    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {
        Collections.swap(switches, fromPosition, toPosition);
        notifyItemMoved(fromPosition, toPosition);
        if (listener != null) {
            listener.onSwitchPositionChanged(switches.get(toPosition), toPosition);
        }
    }

    public void attachToRecyclerView(RecyclerView recyclerView) {
        touchHelper.attachToRecyclerView(recyclerView);
    }

    public void updateSwitches(List<Switch> newSwitches) {
        switches.clear();
        switches.addAll(newSwitches);
        notifyDataSetChanged();
    }

    public void addSwitch(Switch switchItem) {
        switches.add(switchItem);
        notifyItemInserted(switches.size() - 1);
    }

    public void removeSwitch(Switch switchItem) {
        int position = switches.indexOf(switchItem);
        if (position != -1) {
            switches.remove(position);
            notifyItemRemoved(position);
        }
    }

    public void updateSwitch(Switch switchItem) {
        int position = switches.indexOf(switchItem);
        if (position != -1) {
            switches.set(position, switchItem);
            notifyItemChanged(position);
        }
    }

    static class SwitchViewHolder extends RecyclerView.ViewHolder {
        final ImageView switchIcon;
        final TextView switchName;
        final TextView switchStatus;
        final TextView scheduleInfo;
        final SwitchMaterial switchToggle;
        final ImageView connectionType;
        final ImageView dragHandle;

        SwitchViewHolder(View itemView) {
            super(itemView);
            switchIcon = itemView.findViewById(R.id.switchIcon);
            switchName = itemView.findViewById(R.id.switchName);
            switchStatus = itemView.findViewById(R.id.switchStatus);
            scheduleInfo = itemView.findViewById(R.id.scheduleInfo);
            switchToggle = itemView.findViewById(R.id.switchToggle);
            connectionType = itemView.findViewById(R.id.connectionType);
            dragHandle = itemView.findViewById(R.id.dragHandle);
        }
    }

    public interface SwitchItemListener {
        void onSwitchToggled(Switch switchItem, boolean isOn);
        void onSwitchClicked(Switch switchItem);
        void onSwitchLongPressed(Switch switchItem);
        void onSwitchPositionChanged(Switch switchItem, int newPosition);
    }

    public interface ItemTouchHelperAdapter {
        void onItemMove(int fromPosition, int toPosition);
    }
}
