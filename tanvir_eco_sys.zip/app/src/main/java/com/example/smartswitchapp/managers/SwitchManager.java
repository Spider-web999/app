package com.example.smartswitchapp.managers;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.example.smartswitchapp.models.Switch;
import com.example.smartswitchapp.interfaces.ConnectionCallback;

import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SwitchManager {
    private static final String TAG = "SwitchManager";
    private static final UUID BLUETOOTH_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int WIFI_PORT = 8080;
    
    private static SwitchManager instance;
    private final Context context;
    private final ExecutorService executorService;
    private final Handler mainHandler;
    private final List<Switch> switches;
    private final Map<String, BluetoothSocket> bluetoothSockets;
    private final Map<String, Socket> wifiSockets;
    
    private BluetoothAdapter bluetoothAdapter;
    private WifiManager wifiManager;
    
    private SwitchManager(Context context) {
        this.context = context.getApplicationContext();
        this.executorService = Executors.newCachedThreadPool();
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.switches = new ArrayList<>();
        this.bluetoothSockets = new HashMap<>();
        this.wifiSockets = new HashMap<>();
        
        initializeManagers();
    }
    
    public static synchronized SwitchManager getInstance(Context context) {
        if (instance == null) {
            instance = new SwitchManager(context);
        }
        return instance;
    }
    
    private void initializeManagers() {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
    }
    
    public void scanForDevices(ConnectionCallback callback) {
        executorService.execute(() -> {
            // Scan for Bluetooth devices
            if (bluetoothAdapter != null && bluetoothAdapter.isEnabled()) {
                bluetoothAdapter.startDiscovery();
            }
            
            // Scan for WiFi devices
            if (wifiManager != null && wifiManager.isWifiEnabled()) {
                // Implement WiFi discovery logic
            }
        });
    }
    
    public void connectToDevice(Switch device, ConnectionCallback callback) {
        executorService.execute(() -> {
            boolean connected = false;
            
            // Try WiFi first if available
            if (wifiManager.isWifiEnabled() && device.getIpAddress() != null) {
                connected = connectViaWiFi(device);
            }
            
            // Fall back to Bluetooth if WiFi fails
            if (!connected && bluetoothAdapter.isEnabled()) {
                connected = connectViaBluetooth(device);
            }
            
            final boolean finalConnected = connected;
            mainHandler.post(() -> {
                device.setConnected(finalConnected);
                callback.onConnectionStateChanged(device, finalConnected);
            });
        });
    }
    
    private boolean connectViaWiFi(Switch device) {
        try {
            Socket socket = new Socket(device.getIpAddress(), WIFI_PORT);
            wifiSockets.put(device.getId(), socket);
            device.setConnectionType(Switch.ConnectionType.WIFI);
            return true;
        } catch (IOException e) {
            Log.e(TAG, "WiFi connection failed", e);
            return false;
        }
    }
    
    private boolean connectViaBluetooth(Switch device) {
        try {
            BluetoothDevice btDevice = bluetoothAdapter.getRemoteDevice(device.getMacAddress());
            BluetoothSocket socket = btDevice.createRfcommSocketToServiceRecord(BLUETOOTH_UUID);
            socket.connect();
            bluetoothSockets.put(device.getId(), socket);
            device.setConnectionType(Switch.ConnectionType.BLUETOOTH);
            return true;
        } catch (IOException e) {
            Log.e(TAG, "Bluetooth connection failed", e);
            return false;
        }
    }
    
    public void toggleSwitch(Switch device, boolean state, ConnectionCallback callback) {
        executorService.execute(() -> {
            boolean success = false;
            
            if (device.getConnectionType() == Switch.ConnectionType.WIFI) {
                success = sendWiFiCommand(device, state);
            } else if (device.getConnectionType() == Switch.ConnectionType.BLUETOOTH) {
                success = sendBluetoothCommand(device, state);
            }
            
            final boolean finalSuccess = success;
            mainHandler.post(() -> {
                if (finalSuccess) {
                    device.setOn(state);
                }
                callback.onCommandSent(device, finalSuccess);
            });
        });
    }
    
    private boolean sendWiFiCommand(Switch device, boolean state) {
        Socket socket = wifiSockets.get(device.getId());
        if (socket != null && socket.isConnected()) {
            try {
                // Implement command protocol
                String command = state ? "ON" : "OFF";
                socket.getOutputStream().write(command.getBytes());
                return true;
            } catch (IOException e) {
                Log.e(TAG, "Failed to send WiFi command", e);
            }
        }
        return false;
    }
    
    private boolean sendBluetoothCommand(Switch device, boolean state) {
        BluetoothSocket socket = bluetoothSockets.get(device.getId());
        if (socket != null && socket.isConnected()) {
            try {
                // Implement command protocol
                String command = state ? "ON" : "OFF";
                socket.getOutputStream().write(command.getBytes());
                return true;
            } catch (IOException e) {
                Log.e(TAG, "Failed to send Bluetooth command", e);
            }
        }
        return false;
    }
    
    public void disconnectDevice(Switch device) {
        executorService.execute(() -> {
            if (device.getConnectionType() == Switch.ConnectionType.WIFI) {
                Socket socket = wifiSockets.remove(device.getId());
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        Log.e(TAG, "Error closing WiFi socket", e);
                    }
                }
            } else if (device.getConnectionType() == Switch.ConnectionType.BLUETOOTH) {
                BluetoothSocket socket = bluetoothSockets.remove(device.getId());
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        Log.e(TAG, "Error closing Bluetooth socket", e);
                    }
                }
            }
            
            device.setConnected(false);
            device.setConnectionType(Switch.ConnectionType.NONE);
        });
    }
    
    public List<Switch> getSwitches() {
        return new ArrayList<>(switches);
    }
    
    public void addSwitch(Switch device) {
        switches.add(device);
    }
    
    public void removeSwitch(Switch device) {
        disconnectDevice(device);
        switches.remove(device);
    }
    
    public void updateSwitchPosition(Switch device, int newPosition) {
        device.setPosition(newPosition);
        // Implement persistence logic here
    }
    
    public void cleanup() {
        executorService.shutdown();
        for (Switch device : switches) {
            disconnectDevice(device);
        }
    }
}
