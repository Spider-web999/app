package com.example.smartswitchapp;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.smartswitchapp.managers.SwitchManager;
import com.example.smartswitchapp.models.Schedule;
import com.example.smartswitchapp.models.Switch;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.Calendar;
import java.util.Locale;

public class ScheduleActivity extends AppCompatActivity {

    private Switch switchDevice;
    private SwitchManager switchManager;
    
    private TextView startTimeText;
    private TextView endTimeText;
    private Button setStartTimeButton;
    private Button setEndTimeButton;
    private SwitchMaterial enableScheduleSwitch;
    private CheckBox repeatScheduleCheckbox;
    private ChipGroup daysChipGroup;
    private Button saveButton;
    
    private Calendar startTime;
    private Calendar endTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);

        // Get switch device from intent
        String switchId = getIntent().getStringExtra("switch_id");
        switchManager = SwitchManager.getInstance(this);
        for (Switch device : switchManager.getSwitches()) {
            if (device.getId().equals(switchId)) {
                switchDevice = device;
                break;
            }
        }

        if (switchDevice == null) {
            finish();
            return;
        }

        // Initialize UI components
        initializeViews();
        setupToolbar();
        setupTimeSelectors();
        loadExistingSchedule();
    }

    private void initializeViews() {
        startTimeText = findViewById(R.id.startTimeText);
        endTimeText = findViewById(R.id.endTimeText);
        setStartTimeButton = findViewById(R.id.setStartTimeButton);
        setEndTimeButton = findViewById(R.id.setEndTimeButton);
        enableScheduleSwitch = findViewById(R.id.enableScheduleSwitch);
        repeatScheduleCheckbox = findViewById(R.id.repeatScheduleCheckbox);
        daysChipGroup = findViewById(R.id.daysChipGroup);
        saveButton = findViewById(R.id.saveButton);

        startTime = Calendar.getInstance();
        endTime = Calendar.getInstance();
        endTime.add(Calendar.HOUR, 1);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Schedule: " + switchDevice.getName());
        }
    }

    private void setupTimeSelectors() {
        setStartTimeButton.setOnClickListener(v -> showTimePickerDialog(true));
        setEndTimeButton.setOnClickListener(v -> showTimePickerDialog(false));
        
        updateTimeDisplay();

        saveButton.setOnClickListener(v -> saveSchedule());

        enableScheduleSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            setScheduleControlsEnabled(isChecked);
        });
    }

    private void showTimePickerDialog(boolean isStartTime) {
        Calendar calendar = isStartTime ? startTime : endTime;
        
        TimePickerDialog dialog = new TimePickerDialog(
            this,
            (view, hourOfDay, minute) -> {
                if (isStartTime) {
                    startTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    startTime.set(Calendar.MINUTE, minute);
                    
                    // Ensure end time is after start time
                    if (endTime.before(startTime)) {
                        endTime.setTimeInMillis(startTime.getTimeInMillis());
                        endTime.add(Calendar.HOUR, 1);
                    }
                } else {
                    endTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    endTime.set(Calendar.MINUTE, minute);
                    
                    // Ensure start time is before end time
                    if (endTime.before(startTime)) {
                        startTime.setTimeInMillis(endTime.getTimeInMillis());
                        startTime.add(Calendar.HOUR, -1);
                    }
                }
                updateTimeDisplay();
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            true
        );
        
        dialog.show();
    }

    private void updateTimeDisplay() {
        startTimeText.setText(String.format(Locale.getDefault(), "%02d:%02d",
            startTime.get(Calendar.HOUR_OF_DAY),
            startTime.get(Calendar.MINUTE)));
            
        endTimeText.setText(String.format(Locale.getDefault(), "%02d:%02d",
            endTime.get(Calendar.HOUR_OF_DAY),
            endTime.get(Calendar.MINUTE)));
    }

    private void loadExistingSchedule() {
        Schedule existingSchedule = switchDevice.getSchedule();
        if (existingSchedule != null) {
            enableScheduleSwitch.setChecked(true);
            startTime.setTimeInMillis(existingSchedule.getStartTime().getTimeInMillis());
            endTime.setTimeInMillis(existingSchedule.getEndTime().getTimeInMillis());
            repeatScheduleCheckbox.setChecked(existingSchedule.isRecurring());
            updateTimeDisplay();
        } else {
            enableScheduleSwitch.setChecked(false);
            setScheduleControlsEnabled(false);
        }
    }

    private void setScheduleControlsEnabled(boolean enabled) {
        setStartTimeButton.setEnabled(enabled);
        setEndTimeButton.setEnabled(enabled);
        repeatScheduleCheckbox.setEnabled(enabled);
        daysChipGroup.setEnabled(enabled);
    }

    private void saveSchedule() {
        if (enableScheduleSwitch.isChecked()) {
            Schedule schedule = new Schedule(
                startTime,
                endTime,
                repeatScheduleCheckbox.isChecked(),
                getDaysFrequency()
            );
            switchDevice.setSchedule(schedule);
        } else {
            switchDevice.setSchedule(null);
        }
        
        finish();
    }

    private int getDaysFrequency() {
        // Convert selected days chips to frequency integer
        // Implementation depends on your specific requirements
        return 0;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
