package com.example.smartswitchapp.interfaces;

import com.example.smartswitchapp.models.Switch;

public interface ConnectionCallback {
    /**
     * Called when a device's connection state changes
     * @param device The switch device that changed state
     * @param isConnected The new connection state
     */
    void onConnectionStateChanged(Switch device, boolean isConnected);

    /**
     * Called when a command has been sent to a device
     * @param device The switch device that received the command
     * @param success Whether the command was sent successfully
     */
    void onCommandSent(Switch device, boolean success);

    /**
     * Called when a new device is discovered during scanning
     * @param device The newly discovered switch device
     */
    void onDeviceDiscovered(Switch device);

    /**
     * Called when an error occurs during connection or command sending
     * @param device The switch device that encountered the error
     * @param error The error message
     */
    void onError(Switch device, String error);

    /**
     * Called when the device state is synced
     * @param device The switch device that was synced
     */
    void onDeviceSynced(Switch device);
}
