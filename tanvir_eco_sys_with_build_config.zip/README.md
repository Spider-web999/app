# TANVIR SW - Smart Switch Controller

Part of the TANVIR ECO SYS

## Building the APK

### Prerequisites
- Android Studio Arctic Fox (2021.3.1) or newer
- JDK 11 or newer
- Android SDK 33 (Android 13)

### Generate Release Keystore
1. Make the keystore generation script executable:
```bash
chmod +x generate-keystore.sh
```

2. Run the script to generate the keystore:
```bash
./generate-keystore.sh
```

### Build Debug APK
To build a debug version of the app:
```bash
./gradlew assembleDebug
```
The debug APK will be located at: `app/build/outputs/apk/debug/TANVIR_SW_debug_v1.0.apk`

### Build Release APK
To build a release version of the app:
```bash
./gradlew assembleRelease
```
The release APK will be located at: `app/build/outputs/apk/release/TANVIR_SW_release_v1.0.apk`

## Features
- Dual connectivity with WiFi and Bluetooth
- Seamless switching between connection types
- Modern Material Design UI
- Switch state management and persistence
- Scheduling and timer functionality
- Drag-and-drop switch arrangement
- State syncing and relay status tracking

## Project Structure
```
com.tanvir.ecosys/
├── adapters/
│   ├── SwitchAdapter.java
│   └── SwitchItemTouchHelperCallback.java
├── interfaces/
│   └── ConnectionCallback.java
├── managers/
│   └── SwitchManager.java
├── models/
│   ├── Schedule.java
│   └── Switch.java
├── MainActivity.java
└── ScheduleActivity.java
```

## Developer Information
- Developer: Tanvir Ahamed Nayan
- Department: Mechatronics Engineering

## Build Configuration
- minSdkVersion: 21 (Android 5.0)
- targetSdkVersion: 33 (Android 13)
- compileSdkVersion: 33
- buildToolsVersion: Latest stable version

## Release Notes
### Version 1.0
- Initial release
- Basic switch control functionality
- WiFi and Bluetooth support
- Scheduling features
- Modern UI implementation
