#!/bin/bash

# Configuration
KEYSTORE="app/tanvir-release-key.keystore"
KEYSTORE_PASS="tanvir123"
KEY_ALIAS="tanvir-key-alias"
KEY_PASS="tanvir123"
VALIDITY=10000

# Generate keystore
keytool -genkey -v \
        -keystore $KEYSTORE \
        -alias $KEY_ALIAS \
        -keyalg RSA \
        -keysize 2048 \
        -validity $VALIDITY \
        -storepass $KEYSTORE_PASS \
        -keypass $KEY_PASS \
        -dname "CN=Tanvir Ahamed Nayan, OU=Mechatronics Engineering, O=TANVIR ECO SYS, L=Unknown, ST=Unknown, C=BD"

echo "Keystore generated successfully at: $KEYSTORE"
echo "Please keep this file safe and remember the passwords!"
echo "Keystore password: $KEYSTORE_PASS"
echo "Key alias: $KEY_ALIAS"
echo "Key password: $KEY_PASS"
